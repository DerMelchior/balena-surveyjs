//Uncomment this line on creating a culture file
//import { cultureInfo } from "../cultureInfo";

export var englishCulture = {
  shortDateFormats: <Array<any>>[
  ],
  dateSeparators: ["/"],
  currencySymbol: "$"
};

//Uncomment these two lines on creating a translation file. You should replace "en" and enStrings with your locale ("fr", "de" and so on) and your variable.
//cultureInfo.cultures["en"] = englishCulture;
//cultureInfo.cultureNames["en"] = "English";
